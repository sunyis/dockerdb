Live TV Redirect
----------------------------------

A Simple Node copy from
https://github.com/youshandefeiyang/LiveRedirect

## Usage

```bash
npm install
```

```bash
npm start
```

Use your player to play
http://localhost:32888/tv.m3u

## License

MIT